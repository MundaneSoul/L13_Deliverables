package factory.meals;

//import factory.meals.german.GermanMealFactory;
import factory.meals.homefood.HomefoodMealFactory;

public class Driver {

    public static void main(String[] args) {
        //substitute german for homefood (new) from first line in main...
        HomefoodMealFactory mealFactory = new HomefoodMealFactory();
        //GermanMealFactory mealFactory = new GermanMealFactory();
        Hotel hotel = new Hotel(mealFactory);
        hotel.serveMeals();
    }
}
