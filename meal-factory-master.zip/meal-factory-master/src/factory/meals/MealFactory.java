package factory.meals;

public interface MealFactory {

    Meal getMeal(String mealType);
}
