package factory.meals;

public interface Meal {

    void dispayMeal();
}
